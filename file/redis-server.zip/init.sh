#!/bin/bash
set -e

cat ./conf/master.conf> ./master/redis.conf
echo "" > ./master/redis.log

cat ./conf/slave-1.conf > ./slave-1/redis.conf
echo "" > ./slave-1/redis.log
        
cat ./conf/slave-2.conf > ./slave-2/redis.conf
echo "" > ./slave-2/redis.log        
        
cat ./conf/sentinel-1.conf > ./sentinel-1/sentinel.conf
echo "" > ./sentinel-1/sentinel.log
        
cat ./conf/sentinel-2.conf > ./sentinel-2/sentinel.conf
echo "" > ./sentinel-2/sentinel.log
        
cat ./conf/sentinel-3.conf > ./sentinel-3/sentinel.conf
echo "" > ./sentinel-3/sentinel.log

#cat ./slave-1.conf > ./slave-1/redis.conf
#echo "" > ./slave-1/redis.log
        
#cat ./slave-2.conf > ./slave-2/redis.conf
#echo "" > ./slave-2/redis.log        
        
